globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_f739d63f._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__3759f8a9._.js",
      "static/chunks/pages_index_5771e187._.js",
      "static/chunks/pages_index_b08cb4a8._.js"
    ],
    "/_app": [
      "static/chunks/[root-of-the-server]__de6d20b7._.js",
      "static/chunks/node_modules_next_dist_compiled_20fcc6eb._.js",
      "static/chunks/node_modules_next_dist_shared_lib_db861a9a._.js",
      "static/chunks/node_modules_next_dist_client_12050939._.js",
      "static/chunks/node_modules_next_dist_74abe800._.js",
      "static/chunks/node_modules_next_35428634._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_f38ebaa1._.js",
      "static/chunks/styles_globals_79636149.css",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_d350b26e._.js"
    ],
    "/_error": [
      "static/chunks/[root-of-the-server]__8df7605f._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_a51498a5._.js",
      "static/chunks/[root-of-the-server]__923cb372._.js",
      "static/chunks/pages__error_5771e187._.js",
      "static/chunks/pages__error_ec6747c0._.js"
    ],
    "/state": [
      "static/chunks/node_modules_next_a7e515c9._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_motion-dom_dist_es_49526bc8._.js",
      "static/chunks/node_modules_framer-motion_dist_es_b04a0cdb._.js",
      "static/chunks/node_modules_d3-geo_src_0a306d10._.js",
      "static/chunks/node_modules_26347673._.js",
      "static/chunks/[root-of-the-server]__0a4a92f2._.js",
      "static/chunks/pages_state_index_5771e187.js",
      "static/chunks/pages_state_index_459d5eda.js"
    ],
    "/state/[slug]": [
      "static/chunks/node_modules_next_3bd6e58e._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_motion-dom_dist_es_49526bc8._.js",
      "static/chunks/node_modules_framer-motion_dist_es_b04a0cdb._.js",
      "static/chunks/node_modules_d3-geo_src_235fc740._.js",
      "static/chunks/node_modules_26347673._.js",
      "static/chunks/[root-of-the-server]__e5ab3e0a._.js",
      "static/chunks/pages_state_[slug]_5771e187.js",
      "static/chunks/pages_state_[slug]_fb1f0a43.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];