__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_f739d63f._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__3759f8a9._.js",
  "static/chunks/pages_index_5771e187._.js",
  "static/chunks/pages_index_b08cb4a8._.js"
])
