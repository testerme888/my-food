__turbopack_load_page_chunks__("/state", [
  "static/chunks/node_modules_next_a7e515c9._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_motion-dom_dist_es_49526bc8._.js",
  "static/chunks/node_modules_framer-motion_dist_es_b04a0cdb._.js",
  "static/chunks/node_modules_d3-geo_src_0a306d10._.js",
  "static/chunks/node_modules_26347673._.js",
  "static/chunks/[root-of-the-server]__0a4a92f2._.js",
  "static/chunks/pages_state_index_5771e187.js",
  "static/chunks/pages_state_index_459d5eda.js"
])
