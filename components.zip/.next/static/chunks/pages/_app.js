__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root-of-the-server]__de6d20b7._.js",
  "static/chunks/node_modules_next_dist_compiled_20fcc6eb._.js",
  "static/chunks/node_modules_next_dist_shared_lib_db861a9a._.js",
  "static/chunks/node_modules_next_dist_client_12050939._.js",
  "static/chunks/node_modules_next_dist_74abe800._.js",
  "static/chunks/node_modules_next_35428634._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_f38ebaa1._.js",
  "static/chunks/styles_globals_79636149.css",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_d350b26e._.js"
])
