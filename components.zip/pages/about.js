export default function About() {
  return (
    <div className="text-center">
      <h1 className="text-5xl font-bold text-green-600 mb-4">About Page</h1>
      <p className="text-lg text-gray-700">This is the about page of our Next.js project.</p>
    </div>
  )
}
